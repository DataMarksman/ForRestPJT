<template>
  <div id="app">
    <nav>
      
    </nav>
    <router-view/>
  </div>
</template>

<style>

</style>
